#!/usr/bin/env python
# coding: utf-8

# In[40]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt


# In[2]:


import pandas as pd

# Load the dataset
df = pd.read_excel("C:/Users/Sha pa/Downloads/Online Retail.xlsx")  # Encoding specified to avoid errors

# Preview the first 5 rows
print(df.head())


# In[3]:


print(f"Dataset shape: {df.shape}\n")

# Preview the first 5 rows
print(df.head())

# Check column data types and non-null counts
print("\nData info:")
print(df.info())

# Basic stats for numeric columns
print("\nDescriptive statistics:")
print(df.describe())


# #### Data Cleaning

# In[4]:


#Remove rows with missing customer Id
df=df.dropna(subset=['CustomerID'])

#Remove negative values
df=df[(df['Quantity']>0)&(df['UnitPrice']>0)]

#Remove duplicates
df=df.drop_duplicates()


# In[5]:


#Creating TotalPrice Column
df['TotalPrice']=df['Quantity'] * df['UnitPrice']


# In[6]:


df.head()


# ##### Top 5  countries by revenue

# In[7]:


country_revenue=df.groupby('Country')['TotalPrice'].sum().sort_values(ascending=False)
top_5_countries=country_revenue.head()
print(f"Top 5 Countries by Revenue:{top_5_countries}")

#Plotting
top_5_countries.plot(kind='bar',color='skyblue')
plt.title("Top 5 Countries by Revenue")
plt.ylabel('Revenue')
plt.xlabel('Country')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


# In[8]:


df['InvoiceDate']=pd.to_datetime(df['InvoiceDate'])
df['YearMonth']=df['InvoiceDate'].dt.to_period('M')
monthly_revenue=df.groupby('YearMonth')['TotalPrice'].sum().reset_index()
monthly_revenue['YearMonth'] = monthly_revenue['YearMonth'].astype(str)
print(monthly_revenue)

#plotting
plt.figure(figsize=(12,6))
plt.plot(monthly_revenue['YearMonth'],monthly_revenue['TotalPrice'],marker='o',color='teal')
plt.title("Monthly Revenue Trend")
plt.xlabel('Month')
plt.ylabel('Total_Revenue')
plt.grid(True)
plt.tight_layout()
plt.savefig("monthly_revenue_trend.png", dpi=300)  # dpi=300 gives high resolution

plt.show()


# In[15]:


top_products=df.groupby('Description')['Quantity'].sum().sort_values(ascending=False).head(10)
print(top_products)

#plotting
plt.figure(figsize=(10,6))
top_products.sort_values().plot(kind='barh',color='salmon')
plt.title("Top 10 Sold Products")
plt.xlabel('Total Quantity Sold')
plt.ylabel('Product Description')
plt.tight_layout()
plt.savefig("top_10_sold_products.png",dpi=300)
plt.show()


# In[16]:


#Top 10 Customers by Revenue


# In[20]:


df_clean =df.dropna(subset=['CustomerID'])
top_customers=df_clean.groupby('CustomerID')['TotalPrice'].sum().sort_values(ascending=False).head(10)
print("Top 10 Customers by Revenue")
print(top_customers)

#plotting
plt.figure(figsize=(10,6))
top_customers.sort_values().plot(kind='bar', color='blue')
plt.title("Top 10 Customers by Revenue")
plt.xlabel('CustomerID')
plt.ylabel('Total Price')
plt.tight_layout()
plt.savefig("Top_10_Customers_by_Revenue.png",dpi=300)
plt.show()


# In[21]:


#Top 10 Products by Revenue


# In[25]:


top_products_revenue=df.groupby('Description')['TotalPrice'].sum().sort_values(ascending=False).head(10)
print(top_products_revenue)

#plotting
plt.figure(figsize=(10,6))
top_products_revenue.sort_values().plot(kind='barh', color='hotpink')
plt.title("Top Products by Revenue")
plt.xlabel("Total Price")
plt.ylabel("Description")
plt.tight_layout()
plt.savefig("top_products_by_revenge.png",dpi=300)
plt.show()


# In[26]:


#Calculate Recency
#Definition:
#Recency measures how recently a customer made a purchase. A lower number means a more recent purchase.


# In[29]:


latest_date=df['InvoiceDate'].max()
recency_df=df.groupby('CustomerID')['InvoiceDate'].max().reset_index()
recency_df.columns=['CustomerID','LastPurchaseDate']

recency_df['Recency']=(latest_date-recency_df['LastPurchaseDate']).dt.days
recency_df=recency_df.sort_values(by='Recency')
recency_df.head()


# In[30]:


#Calculate Frequency
#Definition:
#Frequency counts how many times a customer made purchases (i.e., number of unique invoices).


# In[32]:


frequency_df=df.groupby('CustomerID')['InvoiceNo'].nunique().reset_index()
frequency_df.columns=['CustomerID','Frequency']
frequency_df=frequency_df.sort_values(by='Frequency',ascending=False)
frequency_df.head()


# In[34]:


monetary_df=df.groupby('CustomerID')['TotalPrice'].sum().reset_index()
monetary_df.columns=['CustomerID','Monetary']
monetary_df=monetary_df.sort_values(by='Monetary',ascending=False)
monetary_df.head()


# In[37]:


rfm=recency_df.merge(frequency_df,on='CustomerID')
rfm=rfm.merge(monetary_df, on='CustomerID')
rfm=rfm.sort_values(by='Monetary',ascending=False)
rfm.head()


# In[39]:


rfm['R_Score']=pd.qcut(rfm['Recency'],4,labels=[4,3,2,1])
rfm['F_Score']=pd.qcut(rfm['Frequency'].rank(method='first'),4,labels=[1,2,3,4])
rfm['M_Score']=pd.qcut(rfm['Monetary'],4,labels=[4,3,2,1])
# Combine into a single score
rfm['RFM_Segment'] = rfm['R_Score'].astype(str) + rfm['F_Score'].astype(str) + rfm['M_Score'].astype(str)
rfm['RFM_Score'] = rfm[['R_Score', 'F_Score', 'M_Score']].astype(int).sum(axis=1)

rfm.head()


# In[45]:


segment_counts=rfm['RFM_Segment'].value_counts().sort_values(ascending=False).head(20)

#Plotting
plt.figure(figsize=(12,6))
sns.barplot(x=segment_counts.index,y=segment_counts.values,palette="viridis")
plt.title("Customer count by RFM Segment")
plt.xlabel('RFM Segment')
plt.ylabel('NUmber of Customers')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("rfm_segment_counts.png",dpi=300)
plt.show()


# In[44]:


# Count by RFM Score (sum of R, F, M scores)
rfm_score_counts = rfm['RFM_Score'].value_counts().sort_index()

# Plot
plt.figure(figsize=(10, 5))
sns.barplot(x=rfm_score_counts.index, y=rfm_score_counts.values, palette="coolwarm")
plt.title('Customer Count by RFM Score')
plt.xlabel('RFM Score (R + F + M)')
plt.ylabel('Number of Customers')
plt.tight_layout()
plt.savefig("rfm_score_distribution.png")
plt.show()


# In[48]:


# Function to assign labels
def segment_customer(row):
    if row['R_Score'] >= 4 and row['F_Score'] >= 4:
        return 'Champions'
    elif row['R_Score'] >= 3 and row['F_Score'] >= 3:
        return 'Loyal Customers'
    elif row['R_Score'] >= 3:
        return 'Potential Loyalist'
    elif row['R_Score'] == 2:
        return 'Needs Attention'
    elif row['R_Score'] == 1 and row['F_Score'] >= 2:
        return 'At Risk'
    else:
        return 'Lost'

# Create new column
rfm['RFM_Label'] = rfm.apply(segment_customer, axis=1)

# Count customers per segment
segment_distribution = rfm['RFM_Label'].value_counts()

# Plot pie chart
plt.figure(figsize=(8, 8))
colors = sns.color_palette('pastel')[0:len(segment_distribution)]
plt.pie(segment_distribution, labels=segment_distribution.index, colors=colors, autopct='%1.1f%%', startangle=140)
plt.title('Customer Segments by RFM Label')
plt.tight_layout()
plt.savefig("rfm_pie_chart.png")
plt.show()


# In[ ]:




