use Ecommerce;
select * from Online_Retail

select Quantity * UnitPrice from Online_Retail;

Alter table Online_Retail
Add revenue float;

update Online_Retail
set revenue=Quantity * UnitPrice;

DELETE FROM Online_Retail 
WHERE InvoiceDate IS NULL;

--Top 10 Countries by Revenue
select Top 10 Country, Sum(revenue) as TotalRevenue
from Online_Retail
group by Country 
order by Sum(revenue) desc;

------Monthly Revenue Trend
Select format(InvoiceDate,'yyyy-MM') As YearMonth, Sum(revenue) as TotalRevenue
from Online_Retail 
group by format(InvoiceDate,'yyyy-MM')
Order by TotalRevenue desc;

----Top 10 Most Sold Products by Quantity
select Top 10 Description ,sum(Quantity) as TotalQuantity
from Online_Retail 
group by Description 
order by sum(Quantity) desc;

---Top products by revenue
select Top 10 Description, Sum(revenue) as TotalRevenue
from Online_Retail
group by Description
order by Sum(revenue) desc;

---Top customers by revenue
select Top 10 CustomerID, Sum(revenue) as TotalRevenue
from Online_Retail
where CustomerID is Not Null
group by CustomerID 
order by Sum(revenue) desc;

--Reference Recent date
SELECT MAX(InvoiceDate) AS ReferenceDate FROM online_retail;

--Customer Segmentation RFM
SELECT
    CustomerID,
    
    -- Recency: Days since last purchase
    DATEDIFF(DAY, MAX(InvoiceDate), '2011-12-09') AS Recency,
    
    -- Frequency: Number of unique purchases (Invoices)
    COUNT(DISTINCT InvoiceNo) AS Frequency,
    
    -- Monetary: Total revenue from the customer
    ROUND(SUM(Quantity * UnitPrice), 2) AS Monetary

FROM online_retail
WHERE CustomerID IS NOT NULL
GROUP BY CustomerID;

-----RFM 
WITH Recency_CTE AS (
    SELECT 
        CustomerID,
        DATEDIFF(DAY, MAX(InvoiceDate), '2011-12-09') AS Recency,
        CASE 
            WHEN DATEDIFF(DAY, MAX(InvoiceDate), '2011-12-09') <= 30 THEN 4
            WHEN DATEDIFF(DAY, MAX(InvoiceDate), '2011-12-09') <= 60 THEN 3
            WHEN DATEDIFF(DAY, MAX(InvoiceDate), '2011-12-09') <= 90 THEN 2
            ELSE 1
        END AS R_Score
    FROM Online_Retail
    WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
),
Frequency_CTE AS (
    SELECT 
        CustomerID,
        COUNT(DISTINCT InvoiceNo) AS Frequency,
        CASE 
            WHEN COUNT(DISTINCT InvoiceNo) >= 100 THEN 4
            WHEN COUNT(DISTINCT InvoiceNo) >= 50 THEN 3
            WHEN COUNT(DISTINCT InvoiceNo) >= 20 THEN 2
            ELSE 1
        END AS F_Score
    FROM Online_Retail
    WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
),
Monetary_CTE AS (
    SELECT 
        CustomerID,
        SUM(Quantity * UnitPrice) AS Monetary,
        CASE 
            WHEN SUM(Quantity * UnitPrice) >= 10000 THEN 4
            WHEN SUM(Quantity * UnitPrice) >= 5000 THEN 3
            WHEN SUM(Quantity * UnitPrice) >= 1000 THEN 2
            ELSE 1
        END AS M_Score
    FROM Online_Retail
    WHERE CustomerID IS NOT NULL
    GROUP BY CustomerID
)
-- Final combination
SELECT 
    r.CustomerID,
    r.R_Score,
    f.F_Score,
    m.M_Score,
    CAST(r.R_Score AS VARCHAR) + CAST(f.F_Score AS VARCHAR) + CAST(m.M_Score AS VARCHAR) AS RFM_Segment,
    (r.R_Score + f.F_Score + m.M_Score) AS RFM_Score
FROM Recency_CTE r
JOIN Frequency_CTE f ON r.CustomerID = f.CustomerID
JOIN Monetary_CTE m ON r.CustomerID = m.CustomerID
ORDER BY RFM_Score DESC;
